Zihang Feng
CS385
jfeng9
							HW 4

	Basically, the program is not doen yet. However, it evaluate the expression string as the only thing that is specified as -print. It works the default path, and any arbitary path. There is no make file needed in this program. User should run it as usual. When the executable runs without anything following, the program would print the files in the current directory and anything folders inside of the that, just like a single dot. When user gives the argument like double dot "..", the program would print everything in the directory right before the current directory and the rest.