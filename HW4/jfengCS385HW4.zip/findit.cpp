// Zihang Feng
// jfeng
// CS385
// HW4

#include <iostream>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string>

using namespace std;

class EvalNode{
public:
	virtual bool eval(char* file_name)=0;
};

class NumNode : public EvalNode
{
public:
	enum data {LESS, EQUAL, GREATER};
protected:
	int testValue;
	data type;
};

class Size : public NumNode
{
	public:

	Size()
	{
		testValue = 0;
		type = EQUAL;
	}
	
	Size(int theValue, data theType)
	{
		testValue = theValue;
		type = theType;
	}

	bool eval(char* file_name)
	{
		struct stat buf;	
		stat(file_name, &buf);
		if(type == LESS)
		{
			if(buf.st_size < testValue)
				return true;
			else return false;
		}
		else if(type == EQUAL)
		{
			if(buf.st_size == testValue)
				return true;
			return false;
		}
		else
		{
			if(buf.st_size > testValue)
				return true;
			return false;
		}
	}
};

class Print : public EvalNode
{
public:
	bool eval(char *file_name)
	{
		cout << file_name << endl;
		return true;
	}
};

class Group : public EvalNode
{
protected:
	EvalNode *leftside, *rightside;
};

class And : public Group
{
public:
	bool eval(char* file_name)
	{
		return (leftside->eval(file_name) && rightside->eval(file_name));
	}

};

class Or : public Group
{
public:
	 bool eval(char* file_name)
        {
                return (leftside->eval(file_name) || rightside->eval(file_name));
        }
};

void print_dir(char* file_name, int found_depth)
{
DIR* start;

	struct dirent *current_dir;
        if((start = opendir(file_name)) != NULL)
        {
                struct stat buf; 

                while((current_dir = readdir(start)) != NULL)
                {
                        if(strcmp(current_dir->d_name,".") != 0 && strcmp(current_dir->d_name,"..") != 0)
                        {
				string dir_path_file = file_name;
				dir_path_file  += "/";
				dir_path_file += current_dir->d_name;
                                if(stat(dir_path_file.c_str(), &buf) != 0)
                                {
					cout << "tried to open '" << dir_path_file << "'" << endl;
                                        perror("Open file with problem");
                                        exit(-1);
                                }

				if(found_depth)
				{
					if(S_ISDIR(buf.st_mode))
                                        print_dir((char*)dir_path_file.c_str(), found_depth);
					
					cout << dir_path_file << endl;

				}
				else
				{
                                	cout << dir_path_file << endl;
                                	if(S_ISDIR(buf.st_mode))
                                		print_dir((char*)dir_path_file.c_str(), found_depth);
				}
                        }
                }
        closedir(start);
	}
        else
        {
                perror("Open file with problem");
                exit(-1);
        }
}
int main(int argc, char** argv)
{
DIR* start;

cout << "Zihang Feng" << endl;
cout << "jfeng" << endl;
cout << endl;

int k = 1;
int found_depth = 0;
while(k < argc)
{
	if(strcmp(argv[k],"-depth") == 0)
	{
		found_depth = 1;
		k = argc;
	}
	k++;
}

// if there is no path specified
// in the current path
if(argc == 1)
{
	cout << "." << endl;
        print_dir(".", 0);

}
else
{
	int no_dash = 0;
	for(int i = 1; i < argc; i++)
	{
		if(argv[i][0] == '-')
		{
			no_dash = i;
			break;
		}
	}


	//build expression tree
	if(no_dash > 0) // either expression or  path and epxression
	{
		if(argv[1][0] == '-')// expression only
		{
			print_dir(".", found_depth);
			cout << "." << endl;
		}
		else// both path and expression
		{
			for(int i = 1; i < no_dash; i++)
                        {
                                print_dir(argv[i], found_depth);
                                cout << argv[i] << endl;
                        }
		}
	}
	else // there is only path
	{
		
		for(int i = 1; i < argc; i++)
		{
			cout << argv[i] << endl;
			print_dir(argv[i],0);	
		}
	}
	
}

return 0;
}
