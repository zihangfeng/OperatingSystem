Zihang Feng
665726671
HW2: IPC and Synchronization

Description:
            I explained everything I can in the master file and the worker file, so that the user would not have any (I hope) issue through reading the program. In this zip file, it contains the make file which means user does not need to compile the both the master and the worker to have the executales. Once the user types make all, there should be two executables avaivable in the current dicrctory, master and worker. Then use the required argument for this assignment. For instance, I personlly use it all the time ./master 11 10 1.0 5.0. Then all values the change of the buffer would be printed out. Since I only finished up to part 4, there is no need to have -lock or -unlock. Bert sometimes does not allow user to create message queue. If it happens, then user should use ernie to run the program. 