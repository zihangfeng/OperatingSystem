#include <stdio.h>
#include <stdlib.h>
#include "struct_file.h"
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <sys/shm.h>
#include <unistd.h>
using namespace std;

int main(int argc, char** argv)
{

int workerID = atoi(argv[1]);
int nBuffers = atoi(argv[2]);
float sleepTime = atof(argv[3]);
int msgID = atoi(argv[4]);

int shmID = atoi(argv[5]);

struct mymsg msgbuf;
msgbuf.type = 1;//it is hello message
msgbuf.worker_ID = workerID;

int *share_memory, *attach_ptr;
share_memory = (int*)shmat(shmID,NULL,0);
attach_ptr = share_memory;

int worker_value = 1 << (workerID - 1);
int temp;
int current_value;
for(int i = 0; i < nBuffers; i++)
{
	// to see if the value in the buffer changed
	temp = i;
	for(int j = 0; j < 2; j++)
	{
		current_value = attach_ptr[temp];
		usleep((int)sleepTime*1000000);
		if(current_value != attach_ptr[temp])
		{
			msgbuf.type = 2;
			sprintf(msgbuf.mtext, "Buffer %d changed from %d to %d.\n", i, current_value, attach_ptr[temp]);
			if(msgsnd(msgID,&msgbuf,sizeof(struct mymsg) - sizeof(long), 0) < 0)
        		{
                	perror("Message send failed.\n");
                	exit(-1);
        		}

		}

		// round robin here
		temp += workerID;
		if( temp >= nBuffers)
			temp -= nBuffers;
	}

	current_value = attach_ptr[temp];
	usleep((int)sleepTime*1000000);
	attach_ptr[temp] = current_value + worker_value;
	temp += workerID;
        if( temp >= nBuffers)
        temp -= nBuffers;
}
if(msgsnd(msgID,&msgbuf,sizeof(struct mymsg) - sizeof(long), 0) < 0)
	{
		perror("Message send failed.\n");
		exit(-1);
	}

shmdt(share_memory);

msgbuf.type = 3; // it is goodbye message

if(msgsnd(msgID,&msgbuf,sizeof(struct mymsg) - sizeof(long), 0) < 0)
        {
                perror("Message send failed.\n");
                exit(-1);
        }

return 0;
}
