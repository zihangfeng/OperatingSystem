#include <sys/msg.h>
#include <sys/types.h>
#include <sys/ipc.h>
struct mymsg{
	long type;
	char mtext[255];
	int worker_ID;
};
