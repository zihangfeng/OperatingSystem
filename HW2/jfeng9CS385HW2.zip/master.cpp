#include <iostream>
#include <sys/wait.h>
#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <fcntl.h>
#include <sys/types.h>
#include <sys/msg.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include "struct_file.h"

using namespace std;


float RandomFloatNumber(float a, float b) {
    float random = ((float) rand()) / (float) RAND_MAX; // 0.0 to 1.0
    float diff = b - a; // 5.0 - 1.0 = 4.0
    float r = random * diff;
    return a + r;
}

int main(int argc, char **argv)
{ 
int fd1[2], fd2[2]; 
pid_t pid;

// get two pipes
pipe(fd1);
int pipe1Read = fd1[0]; 
int pipe1Write = fd1[1]; 
pipe(fd2); 
int pipe2Read = fd2[0]; 
int pipe2Write = fd2[1];


	pid = fork();

	if(pid < 0)
	{
		printf("Fork Error.");
		exit(-1);
	}
	else if(pid == 0)// in the child process
	{
		printf("In the Child process.\n");
		dup2(pipe1Read, 0);
		dup2(pipe2Write,1);
		close(pipe1Read);
		close(pipe1Write);
		close(pipe2Write);
		close(pipe2Read);
		execlp("sort","sort","-nr",NULL);		
	}
	else// in the parent process
	{
		printf("Now in the Parent process.\n");
		close(pipe1Read);
		close(pipe2Write);
		float sleepMin = atof(argv[3]);
		float sleepMax = atof(argv[4]);

		int nWorkers = atoi(argv[2]);
		char *buffer = new char[nWorkers*80];

		printf("The workers values before writing into pipe 1\n");
		for(int i = 0; i < nWorkers; i++)
		{
			sprintf(buffer+i*80,"%f\n",RandomFloatNumber(sleepMin,sleepMax));
			printf("%s",buffer+i*80);
			write(pipe1Write,buffer+i*80,strlen(buffer+i*80));
		}
		write(pipe1Write,"",1);
		printf("\n");
		close(pipe1Write);

		// in and out of the sort file
		wait(NULL);
		for(int i = 0; i< nWorkers; i++)
		{
			read(pipe2Read, buffer, nWorkers*80);
		}
		close(pipe2Read);
		printf("%s", buffer);
		// part 1 done


		// part 2, 3, 4 must work together in order to complete their goal
		int nBuffers = atoi(argv[1]);
		int msgID;
		if((msgID = msgget(IPC_PRIVATE, S_IRUSR | S_IWUSR | IPC_CREAT)) == -1)
		{
			perror("Message ID Error.\n");
			exit(-1);
		}
		
		int shmID;
		if((shmID = shmget(IPC_PRIVATE, nBuffers,  S_IRUSR | S_IWUSR | IPC_CREAT)) == -1)
		{
			perror("Share Memory ID Error.\n");
		}
		
		char str_msgID[6], str_shmID[6];
		sprintf(str_msgID,"%i", msgID);
		sprintf(str_shmID,"%i", shmID);


		// the begining of the share memory
		int *share_memory, *attach_ptr;
		share_memory = (int*)shmat(shmID, NULL, 0);
		attach_ptr = share_memory;
		memset(attach_ptr,0,sizeof(int)*nBuffers);// here zero out all apots of the share memory array
		

		// execute the worker processes
		char **sleeptime = new char*[nWorkers];
		for(int i = 1; i <= nWorkers; i++)
		{
			pid = fork();
			if(pid < 0)
			{
				perror("Erorr on forking the workers\n");
				exit(-1);
			}
			else if(pid == 0)
			{	
				if(i == 1)
				{
					sleeptime[i-1] = strtok(buffer,"\n");
				}
				else
				{
					sleeptime[i-1] = strtok(NULL, "\n");
				}
				char worker_ID[3];
				sprintf(worker_ID, "%d", i);
				printf("I am in the Child process");
				execlp("./worker", "./worker", worker_ID, argv[1], sleeptime, str_msgID, str_shmID, NULL);
				perror("Something went wrong.\n");
				exit(-1);
			}
				
		}


		// receive the values from the workers
		struct mymsg msgbuf;
		int i = nWorkers;
		
		while(i)
		{
			if(msgrcv(msgID,&msgbuf,sizeof(struct mymsg) - sizeof(long),0,0) == -1)// This is where the master receive the message from the queue
			{
				perror("Message Receive Failed.\n");
				exit(-1);
			}
			
			if(msgbuf.type == 1)
			{
				printf("It is Hello message from Worker %d.\n",msgbuf.worker_ID);
			}
			else if(msgbuf.type == 2)
			{
				printf("The Worker %d of %s", msgbuf.worker_ID, msgbuf.mtext);
			}
			else if(msgbuf.type == 3)
			{
				printf("It is the Goodbye message from Worker %d.\n", msgbuf.worker_ID);
				i--;
			}
			else
			{
				printf("Some else it the worker ID.\n");
			}
		}
		
		i = 0;

		// wait the all child to come back
		while(i < nWorkers)
		{
			wait(NULL);
			i++;
		}
		i = 0;
		while(i < nBuffers)
		{
			printf("the value from the share memory %d\n", share_memory[i]);
			i++;
		}
		shmdt(share_memory);
		msgctl(msgID, IPC_RMID, NULL);
		shmctl(shmID, IPC_RMID, NULL);	
	}

return 0;
}
